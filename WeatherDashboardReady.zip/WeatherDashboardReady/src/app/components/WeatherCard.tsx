import { Cloud, Droplets, Wind, Thermometer, MapPin } from 'lucide-react';

interface WeatherData {
  city: string;
  country: string;
  temperature: number;
  feelsLike: number;
  humidity: number;
  windSpeed: number;
  description: string;
  icon: string;
}

interface WeatherCardProps {
  weather: WeatherData;
}

export function WeatherCard({ weather }: WeatherCardProps) {
  return (
    <div className="bg-black/30 border border-white/10 backdrop-blur-xl rounded-3xl shadow-2xl p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <MapPin className="w-5 h-5" />
          <h2 className="text-2xl font-bold">
            {weather.city}, {weather.country}
          </h2>
        </div>
      </div>

      <div className="flex items-center justify-between mb-8">
        <div>
          <div className="text-7xl font-thin tracking-widest">
            {Math.round(weather.temperature)}°C
          </div>
          <p className="text-blue-100 text-lg capitalize">{weather.description}</p>
          <p className="text-blue-200 text-sm mt-1">
            Feels like {Math.round(weather.feelsLike)}°C
          </p>
        </div>
        <Cloud className="w-24 h-24 text-blue-100" />
      </div>

      <div className="grid grid-cols-3 gap-4">
        <div className="bg-white/20 backdrop-blur-sm rounded-xl p-4">
          <div className="flex items-center gap-2 mb-2">
            <Thermometer className="w-5 h-5" />
            <span className="text-sm text-blue-100">Temp</span>
          </div>
          <p className="text-xl font-semibold">{Math.round(weather.temperature)}°C</p>
        </div>

        <div className="bg-white/20 backdrop-blur-sm rounded-xl p-4">
          <div className="flex items-center gap-2 mb-2">
            <Droplets className="w-5 h-5" />
            <span className="text-sm text-blue-100">Humidity</span>
          </div>
          <p className="text-xl font-semibold">{weather.humidity}%</p>
        </div>

        <div className="bg-white/20 backdrop-blur-sm rounded-xl p-4">
          <div className="flex items-center gap-2 mb-2">
            <Wind className="w-5 h-5" />
            <span className="text-sm text-blue-100">Wind</span>
          </div>
          <p className="text-xl font-semibold">{weather.windSpeed} m/s</p>
        </div>
      </div>
    </div>
  );
}
