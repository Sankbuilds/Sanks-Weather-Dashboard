const API_KEY = 'ed6411db9e1a640fd410cf34e219fb0e';
const BASE_URL = 'https://api.openweathermap.org/data/2.5/weather';

interface WeatherData {
  city: string;
  country: string;
  temperature: number;
  feelsLike: number;
  humidity: number;
  windSpeed: number;
  description: string;
  icon: string;
}

interface OpenWeatherResponse {
  name: string;
  sys: {
    country: string;
  };
  main: {
    temp: number;
    feels_like: number;
    humidity: number;
  };
  wind: {
    speed: number;
  };
  weather: Array<{
    description: string;
    icon: string;
  }>;
}

export async function fetchWeatherData(
  city: string
): Promise<WeatherData> {
  try {

    const url =
      `${BASE_URL}?q=${encodeURIComponent(city)}&appid=${API_KEY}&units=metric`;

    const response = await fetch(url);

    if (!response.ok) {

      if (response.status === 404) {
        throw new Error(
          `City "${city}" not found.`
        );
      }

      if (response.status === 401) {
        throw new Error(
          'Invalid API key.'
        );
      }

      throw new Error(
        'Failed to fetch weather data.'
      );
    }

    const data: OpenWeatherResponse =
      await response.json();

    const weatherData: WeatherData = {
      city: data.name,
      country: data.sys.country,
      temperature: data.main.temp,
      feelsLike: data.main.feels_like,
      humidity: data.main.humidity,
      windSpeed: data.wind.speed,
      description: data.weather[0].description,
      icon: data.weather[0].icon
    };

    return weatherData;

  } catch (error) {

    if (error instanceof TypeError) {
      throw new Error(
        'Network error. Check internet connection.'
      );
    }

    if (error instanceof Error) {
      throw error;
    }

    throw new Error(
      'Unexpected error occurred.'
    );
  }
}