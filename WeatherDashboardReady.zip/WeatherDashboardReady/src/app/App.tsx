import { useState } from 'react';
import { WeatherCard } from './components/WeatherCard';
import { SearchBar } from './components/SearchBar';
import { ErrorMessage } from './components/ErrorMessage';
import { LoadingSpinner } from './components/LoadingSpinner';
import { fetchWeatherData } from './services/weatherService';

interface WeatherData {
  city: string;
  country: string;
  temperature: number;
  feelsLike: number;
  humidity: number;
  windSpeed: number;
  description: string;
  icon: string;
}

export default function App() {
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [lastSearchedCity, setLastSearchedCity] = useState<string>('');

  const handleSearch = async (city: string) => {
    setIsLoading(true);
    setError(null);
    setLastSearchedCity(city);

    try {
      const data = await fetchWeatherData(city);
      setWeather(data);
    } catch (err) {
      if (err instanceof Error) {
        setError(err.message);
      } else {
        setError('An unexpected error occurred. Please try again.');
      }
      setWeather(null);
    } finally {
      setIsLoading(false);
    }
  };

  const handleRetry = () => {
    if (lastSearchedCity) {
      handleSearch(lastSearchedCity);
    }
  };

  return (
   <div
  className="min-h-screen bg-cover bg-center text-white"
  style={{
    backgroundImage:
      "url('https://images.pond5.com/weather-forecast-background-time-lapse-footage-036432391_iconl.jpeg')",
  }}
>
  <div className="min-h-screen bg-black/50 backdrop-blur-sm">
      <div className="text-center mb-12">
        <h1 className="text-5xl font-bold text-white drop-shadow-[0_0_20px_rgba(255,255,255,0.5)]">
          Sanks Weather Dashboard
        </h1>
        <p className="text-lg font-medium bg-gradient-to-r from-cyan-300 to-blue-500 bg-clip-text text-transparent">
          Search for real-time weather data from around the world
        </p>
      </div>

     <div className="flex justify-center mb-10">
  <SearchBar onSearch={handleSearch} isLoading={isLoading} />
</div>

      <div className="flex items-center justify-center min-h-[400px]">
        {isLoading && <LoadingSpinner />}

        {!isLoading && error && (
          <ErrorMessage message={error} onRetry={handleRetry} />
        )}

        {!isLoading && !error && weather && (
          <WeatherCard weather={weather} />
        )}

        {!isLoading && !error && !weather && (
          <div className="text-center bg-gradient-to-r from-purple-300 to-cyan-400 bg-clip-text text-transparent">
            <p className="text-lg">Enter a city name to get started</p>
            <p className="text-sm mt-2">Try: Mumbai, Nashik, Tokyo, Spain 
              Or your city name
            </p>
          </div>
        )}
        </div>
      </div>
    </div>
  );
}