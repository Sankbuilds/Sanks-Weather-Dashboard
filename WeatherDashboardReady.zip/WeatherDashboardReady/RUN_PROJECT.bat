@echo off
title Weather Dashboard
echo Installing dependencies...
npm install
echo.
echo Starting project...
npm run dev
pause
echo done
